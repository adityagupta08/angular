import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Book} from './book';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  constructor(private httpservice: HttpClient) { }
  arrbooks: Book[];

  ngOnInit() {
    this.httpservice.get('./assets/booklist.json').subscribe(

      data => {
        this.arrbooks = data as Book[];

      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }


}
