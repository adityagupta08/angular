import { TablefilterPipe } from './tablefilter.pipe';

describe('TablefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TablefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
