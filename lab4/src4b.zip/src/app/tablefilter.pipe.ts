import { Pipe, PipeTransform } from '@angular/core';
import {Book} from './book';


@Pipe({
  name: 'tablefilter'
})
export class TablefilterPipe implements PipeTransform {

  transform(value: Book[],id:number,title:string,author:string,year:number):Book[] {
    
    if(id!=null)
    {
      var ids = id.toString();
      return value.filter(x=>{return x.id.toString().includes(ids);})

    }
    if(title!=null)
    {
      var title = title.toLocaleLowerCase();
      return value.filter(x=>{return x.title.toLocaleLowerCase().includes(title);})

    }
    if(author!=null)
    {
      var author = author.toLocaleLowerCase();
      return value.filter(x=>{return x.author.toLocaleLowerCase().includes(author);})

    }
    if(year!=null)
    {
      var years = year.toString();
      return value.filter(x=>{return x.year.toString().includes(years);})

    }



    return value;
  }

}
