import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Book} from './book';
//import {TablefilterPipe} from './tablefilter.pipe';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  app = 'app';
id:number;
title:string;
author:string;
year:number;








  constructor(private httpservice: HttpClient) { }
  arrbooks: Book[];

  ngOnInit() {
    this.httpservice.get('./assets/booklist.json').subscribe(

      data => {
        this.arrbooks = data as Book[];

      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }

  changeId():void{
    this.id=null;
  }
  changeTitle():void{
    this.title=null;
  }
  changeAuthor():void{
    this.author=null;
  }
  changeYear():void{
    this.year=null;
  }


}
